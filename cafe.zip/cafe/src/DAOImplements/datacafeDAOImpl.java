/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package DAOImplements;
import java.util.List;
import model.*;

/**
 *
 * @author ASUS
 */
public interface datacafeDAOImpl {
    public void insert(datacafe p);
    public void update(datacafe p);
    public void deleted(int id);
    public void deletep(int id);
    public void deletet(int id);
    public void inserthasil(datacafe p);
    public void setPelanggan(datacafe p);
    public List<datacafe> getAll();
    public List<datacafe> getAlltotal();
    public List<datacafe> getAllTransaksi();
    public List<datacafe> getAllPelanggan();
    public List<datacafe> getAkun(String username);
    void calculateAndInsertTotalHarga();
    void calculateAndInsertTotalHargariwayat();
}
