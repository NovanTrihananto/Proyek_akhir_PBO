/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAOcontroller;
import DAOImplements.datacafeDAOImpl;
import DAOdatacafe.datacafeDAO;
import java.util.List;
import model.datacafe;
import view.PelangganView;
/**
 *
 * @author Farizall
 */
public class datapelanggancontroller {
    PelangganView frame;
    datacafeDAOImpl impldatacafe;
    
    public datapelanggancontroller (PelangganView frame) {
        this.frame = frame;
        impldatacafe = new datacafeDAO();
    }
    
    public void insertt(){
        datacafe pelanggan = new datacafe();
        pelanggan.setNama_pelanggan(frame.getPelanggan().getText());
        impldatacafe.setPelanggan(pelanggan);
    }
}


