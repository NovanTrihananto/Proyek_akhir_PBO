package DAOcontroller;

import java.util.List;
import DAOdatacafe.datacafeDAO;
import DAOImplements.datacafeDAOImpl;
import model.*;
import view.MainView;

/**
 * Kelas datacafecontroller
 * Mengatur interaksi antara model dan view
 */
public class datacafecontroller {
    MainView frame;
    datacafeDAOImpl impldatacafe;
    List<datacafe> dh;

    public datacafecontroller(MainView frame) {
        this.frame = frame;
        impldatacafe = new datacafeDAO();
    }

    public void isitabel() {
        dh = impldatacafe.getAll();
        modeltabeldatacafe mp = new modeltabeldatacafe(dh);
        frame.getTabelmenu().setModel(mp);
    }

    public void isipelanggan() {
        dh = impldatacafe.getAllPelanggan();
        modeltabelpelanggan ap = new modeltabelpelanggan(dh);
        frame.getTablepelanggan().setModel(ap);
    }

    public void isitransaksi() {
        dh = impldatacafe.getAllTransaksi();
        tabeltransaksi tp = new tabeltransaksi(dh);
        frame.getTabeltransaksi().setModel(tp);
    }

    public void isihasil() {
        dh = impldatacafe.getAlltotal();
        modeltabeltotal tp = new modeltabeltotal(dh);
        frame.getTabelhasil().setModel(tp);
    }

    public void insert() {
        datacafe dh = new datacafe();
        dh.setNama_barang(frame.getJtnb().getText());
        dh.setJenis(frame.getJtj().getText());
        dh.setHarga(Integer.parseInt(frame.getJth().getText()));
        dh.setQuantity(Integer.parseInt(frame.getJtq().getText()));
        dh.setId(Integer.parseInt(frame.getJtid().getText()));
        impldatacafe.insert(dh);
        isitabel(); // Memperbarui tabel setelah insert
        isitransaksi(); 
        calculateAndInsertTotalHarga(); // Perbarui total harga setelah insert
        isihasil(); // Memperbarui tabel hasil setelah total harga diperbarui
    }

    public void inserthasil() {
        datacafe dh = new datacafe();
        dh.setId(Integer.parseInt(frame.getJtid().getText()));
        impldatacafe.inserthasil(dh);
        isitabel(); // Memperbarui tabel setelah insert
        isitransaksi();
        calculateAndInsertTotalHarga(); // Perbarui total harga setelah insert hasil
        isihasil(); // Memperbarui tabel hasil setelah total harga diperbarui
    }

    public void calculateAndInsertTotalHarga() {
        impldatacafe.calculateAndInsertTotalHarga();
    }
    
    public void calculateAndInsertTotalHargariwayat() {
        impldatacafe.calculateAndInsertTotalHarga();
    }
    
    public void deleted(){
        int id = (Integer.parseInt(frame.getI().getText()));
        impldatacafe.deleted(id);
    } 
    
    public void deletep(){
        int id = (Integer.parseInt(frame.getI().getText()));
        impldatacafe.deletep(id);
    } 
    public void deletet(){
        int id = (Integer.parseInt(frame.getI().getText()));
        impldatacafe.deletet(id);
    } 
    public void clearFields() {
    datacafe dh = new datacafe();
    frame.getJth().setText("");
    frame.getJtj().setText("");
    frame.getJtnb().setText("");
    frame.getJtq().setText("");
    frame.getJtid().setText("");
    frame.getI().setText(""); 
    frame.getTb().setText(""); 
    impldatacafe.update(dh);
}
    public void update(){
        datacafe dh = new datacafe();
        dh.setQuantity(Integer.parseInt(frame.getJtq().getText()));
        dh.setHarga(Integer.parseInt(frame.getJth().getText()));
        dh.setId_pelanggan(Integer.parseInt(frame.getIdp().getText()));
        impldatacafe.update(dh);
        
    }
    
}
