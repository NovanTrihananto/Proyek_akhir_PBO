/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAOcontroller;
import java.util.List;
import view.LoginView;
import view.MainView;
import DAOImplements.datacafeDAOImpl;
import model.*;
import DAOdatacafe.datacafeDAO;
import javax.swing.JOptionPane;
import view.PelangganView;
/**
 *
 * @author Farizall
 */
public class datalogincontroller {
    LoginView frame;
    datacafeDAOImpl impldatacafe;
    List<datacafe> cek;
    
    public datalogincontroller(LoginView frame){
        this.frame = frame;
        impldatacafe = new datacafeDAO();
    }
    
    public void cekakun() {
        String username = frame.getUsername().getText();
        String password = frame.getPassword().getText();
        List<datacafe> cek = impldatacafe.getAkun(username);
        
        if (cek != null && !cek.isEmpty()) {
            datacafe cf = cek.get(0);
            if (password.equals(cf.getPassword())) {
                PelangganView v = new PelangganView(cf);
                v.setVisible(true);
                v.setLocationRelativeTo(null);
            } else {
                JOptionPane.showMessageDialog(frame, "Password Salah!", "Message", JOptionPane.INFORMATION_MESSAGE);
            }
        } else {
            JOptionPane.showMessageDialog(frame, "Akun Tidak Ditemukan, Silahkan Buat Akun Terlebih Dahulu", "Message", JOptionPane.INFORMATION_MESSAGE);   
        }
        
        
    }
}
