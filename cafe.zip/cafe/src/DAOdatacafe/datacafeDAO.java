package DAOdatacafe;

import java.sql.*;
import java.util.*;
import cafe.koneksi.koneksi;
import model.*;
import DAOImplements.datacafeDAOImpl;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Kelas datacafeDAO
 * Implementasi metode untuk mengelola data dalam tabel database
 */
public class datacafeDAO implements datacafeDAOImpl {
    Connection connection;

    final String select = "SELECT * FROM barang";
    final String insert = "INSERT INTO detail_transaksi (nama_barang, jenis, quantity, harga, hargaQTY, id) VALUES (?,?,?,?,?,?);";
    final String update = "UPDATE detail_transaksi set quantity=?, harga=? WHERE id_pelanggan=?;";
    final String deleted = "DELETE FROM detail_transaksi WHERE id=?;";
    final String deletep = "DELETE FROM total WHERE id=?;";
    final String deletet = "DELETE FROM transaksi WHERE id=?;";
    final String akun = "SELECT * FROM pegawai WHERE username = ?;";
    final String insert_p = "INSERT INTO transaksi (nama_pelanggan) VALUES (?);";
    final String selectdetailtransaksi = "SELECT * FROM detail_transaksi;";
    final String selectTransaksi = "SELECT * FROM transaksi";
    final String selecthasil = "SELECT * FROM total";
    final String inserthasil = "INSERT INTO total (id, total_biaya) VALUES (?,?);";

    public datacafeDAO() {
        connection = koneksi.connection();
    }

    @Override
    public void insert(datacafe transaksiList) {
        PreparedStatement statement = null;
        try {
            statement = connection.prepareStatement(insert, Statement.RETURN_GENERATED_KEYS);
            statement.setString(1, transaksiList.getNama_barang());
            statement.setString(2, transaksiList.getJenis());
            statement.setInt(3, transaksiList.getQuantity());
            statement.setInt(4, transaksiList.getHarga());
            statement.setInt(5, transaksiList.getTotal_harga());
            statement.setInt(6, transaksiList.getId());
            statement.executeUpdate();
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            try {
                if (statement != null) statement.close();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }

    public void inserthasil(datacafe transaksiList) {
        PreparedStatement statement = null;
        try {
            statement = connection.prepareStatement(inserthasil, Statement.RETURN_GENERATED_KEYS);
            statement.setInt(1, transaksiList.getId());
            statement.setInt(2, transaksiList.getTotal_biaya());
            statement.executeUpdate();
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            try {
                if (statement != null) statement.close();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }

    public void update(datacafe m) {
        PreparedStatement statement = null;
        try {
            statement = connection.prepareStatement(update);
            statement.setInt(1, m.getQuantity());
            statement.setInt(2, m.getHarga());
            statement.setInt(3, m.getId_pelanggan());
            statement.executeUpdate();
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            try {
                if (statement != null) statement.close();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }

    public void deleted(int id) {
        PreparedStatement statement = null;
        try {
            statement = connection.prepareStatement(deleted);
            statement.setInt(1, id);
            statement.executeUpdate();
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            try {
                if (statement != null) statement.close();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }
    public void deletep(int id) {
        PreparedStatement statement = null;
        try {
            statement = connection.prepareStatement(deletep);
            statement.setInt(1, id);
            statement.executeUpdate();
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            try {
                if (statement != null) statement.close();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }
    public void deletet(int id) {
        PreparedStatement statement = null;
        try {
            statement = connection.prepareStatement(deletet);
            statement.setInt(1, id);
            statement.executeUpdate();
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            try {
                if (statement != null) statement.close();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }



    @Override
    public List<datacafe> getAll() {
        List<datacafe> dm = new ArrayList<>();
        try {
            Statement st = connection.createStatement();
            ResultSet rs = st.executeQuery(select);
            while (rs.next()) {
                datacafe md = new datacafe();
                md.setId_barang(rs.getInt("id_barang"));
                md.setNama(rs.getString("nama"));
                md.setJenis(rs.getString("jenis"));
                md.setHarga(rs.getInt("harga"));
                dm.add(md);
            }
        } catch (SQLException ex) {
            Logger.getLogger(datacafeDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return dm;
    }

    @Override
    public List<datacafe> getAlltotal() {
        List<datacafe> dh = new ArrayList<>();
        try {
            Statement st = connection.createStatement();
            ResultSet rs = st.executeQuery(selecthasil);
            while (rs.next()) {
                datacafe dr = new datacafe();
                dr.setId(rs.getInt("id"));
                dr.setTotal_biaya(rs.getInt("total_biaya"));
                dh.add(dr);
            }
        } catch (SQLException ex) {
            Logger.getLogger(datacafeDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return dh;
    }

    @Override
    public List<datacafe> getAllTransaksi() {
        List<datacafe> dh = new ArrayList<>();
        try {
            Statement st = connection.createStatement();
            ResultSet rs = st.executeQuery(selectdetailtransaksi);
            while (rs.next()) {
                datacafe dr = new datacafe();
                dr.setId_pelanggan(rs.getInt("id_pelanggan"));
                dr.setNama_barang(rs.getString("nama_barang"));
                dr.setJenis(rs.getString("jenis"));
                dr.setQuantity(rs.getInt("quantity"));
                dr.setHarga(rs.getInt("harga"));
                dr.setId(rs.getInt("id"));
                dh.add(dr);
            }
        } catch (SQLException ex) {
            Logger.getLogger(datacafeDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return dh;
    }

    @Override
    public List<datacafe> getAllPelanggan() {
        List<datacafe> dh = new ArrayList<>();
        try {
            Statement st = connection.createStatement();
            ResultSet rs = st.executeQuery(selectTransaksi);
            while (rs.next()) {
                datacafe ts = new datacafe();
                ts.setId(rs.getInt("id"));
                ts.setNama_pelanggan(rs.getString("nama_pelanggan"));
                dh.add(ts);
            }
        } catch (SQLException ex) {
            Logger.getLogger(datacafeDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return dh;
    }

    @Override
    public List<datacafe> getAkun(String username) {
        List<datacafe> dz = new ArrayList<>();
        try {
            PreparedStatement ps = connection.prepareStatement(akun);
            ps.setString(1, username);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                datacafe zoo = new datacafe();
                zoo.setUsername(rs.getString("username"));
                zoo.setPassword(rs.getString("password"));
                dz.add(zoo);
            }
        } catch (SQLException ex) {
            Logger.getLogger(datacafeDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return dz;
    }

    @Override
    public void setPelanggan(datacafe pelangan) {
        PreparedStatement statement = null;
        try {
            statement = connection.prepareStatement(insert_p, Statement.RETURN_GENERATED_KEYS);
            statement.setString(1, pelangan.getNama_pelanggan());
            statement.executeUpdate();
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            try {
                if (statement != null) statement.close();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }

    @Override
    public void calculateAndInsertTotalHarga() {
    PreparedStatement selectStatement = null;
    PreparedStatement insertStatement = null;
    ResultSet resultSet = null;
    try {
        // Query SQL untuk menjumlahkan 'harga' berdasarkan 'id'
        String sumQuery = "SELECT id, SUM(hargaQTY) AS total_harga FROM detail_transaksi GROUP BY id";
        selectStatement = connection.prepareStatement(sumQuery);
        resultSet = selectStatement.executeQuery();

        // Siapkan statement untuk insert ke tabel 'total'
        String insertTotalQuery = "INSERT INTO total (id, total_biaya) VALUES (?, ?) ON DUPLICATE KEY UPDATE total_biaya = VALUES(total_biaya)";
        insertStatement = connection.prepareStatement(insertTotalQuery);

        // Iterasi melalui result set dan masukkan ke dalam tabel 'total'
        while (resultSet.next()) {
            int id = resultSet.getInt("id");
            int totalHarga = resultSet.getInt("total_harga");

            // Set parameter untuk insert statement
            insertStatement.setInt(1, id);
            insertStatement.setInt(2, totalHarga);
            insertStatement.executeUpdate();
        }
    } catch (SQLException ex) {
        ex.printStackTrace();
    } finally {
        try {
            if (resultSet != null) resultSet.close();
            if (selectStatement != null) selectStatement.close();
            if (insertStatement != null) insertStatement.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
            }
        }
    }
    
    public void calculateAndInsertTotalHargariwayat() {
    PreparedStatement selectStatement = null;
    PreparedStatement insertStatement = null;
    ResultSet resultSet = null;
    try {
        // Query SQL untuk menjumlahkan 'harga' berdasarkan 'id'
        String sumQuery = "SELECT id, SUM(hargaQTY) AS total_harga FROM detail_transaksi GROUP BY id";
        selectStatement = connection.prepareStatement(sumQuery);
        resultSet = selectStatement.executeQuery();

        // Siapkan statement untuk insert ke tabel 'total'
        String insertTotalQuery = "INSERT INTO riwayat_transaksi (id, total_biaya) VALUES (?, ?) ON DUPLICATE KEY UPDATE total_biaya = VALUES(total_biaya)";
        insertStatement = connection.prepareStatement(insertTotalQuery);

        // Iterasi melalui result set dan masukkan ke dalam tabel 'total'
        while (resultSet.next()) {
            int id = resultSet.getInt("id");
            int totalHarga = resultSet.getInt("total_harga");

            // Set parameter untuk insert statement
            insertStatement.setInt(1, id);
            insertStatement.setInt(2, totalHarga);
            insertStatement.executeUpdate();
        }
    } catch (SQLException ex) {
        ex.printStackTrace();
    } finally {
        try {
            if (resultSet != null) resultSet.close();
            if (selectStatement != null) selectStatement.close();
            if (insertStatement != null) insertStatement.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
            }
        }
    }
}
