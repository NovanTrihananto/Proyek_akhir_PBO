package model;

public class datacafe {
    
    private int id_barang;
    private String nama_barang;
    private String jenis;
    private String nama;
    private int quantity;
    private int harga;
    private int total_harga;
    private int id;
    private String nama_pelanggan;
    private String username;
    private String password;
    private int total_biaya;
    private int id_pelanggan;

    // Getter dan Setter untuk total_biaya
    public int getTotal_biaya() {
        return total_biaya;
    }

    public int getId_pelanggan() {
        return id_pelanggan;
    }

    public void setId_pelanggan(int id_pelanggan) {
        this.id_pelanggan = id_pelanggan;
    }
    
    
    
    public void setTotal_biaya(int total_biaya) {
        this.total_biaya = total_biaya;
    }

    // Getter dan Setter untuk id_pelanggan

    // Getter dan Setter untuk id_barang
    public int getId_barang() {
        return id_barang;
    }

    public void setId_barang(int id_barang) {
        this.id_barang = id_barang;
    }

    // Getter dan Setter untuk nama_barang
    public String getNama_barang() {
        return nama_barang;
    }

    public void setNama_barang(String nama_barang) {
        this.nama_barang = nama_barang;
    }

    // Getter dan Setter untuk nama_pelanggan
    public String getNama_pelanggan() {
        return nama_pelanggan;
    }

    public void setNama_pelanggan(String nama_pelanggan) {
        this.nama_pelanggan = nama_pelanggan;
    }

    // Getter dan Setter untuk id
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    // Getter dan Setter untuk nama
    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    // Getter dan Setter untuk jenis
    public String getJenis() {
        return jenis;
    }

    public void setJenis(String jenis) {
        this.jenis = jenis;
    }

    // Getter dan Setter untuk quantity
    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    // Getter dan Setter untuk harga
    public int getHarga() {
        return harga;
    }

    public void setHarga(int harga) {
        this.harga = harga;
    }

    // Getter dan Setter untuk username
    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    // Getter dan Setter untuk password
    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    // Getter dan Setter untuk total_harga
    public int getTotal_harga() {
        return quantity * harga;
    }

    public void setTotal_harga(int total_harga) {
        this.total_harga = total_harga;
    }
}
