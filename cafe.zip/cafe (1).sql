-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 28 Bulan Mei 2024 pada 18.28
-- Versi server: 10.4.32-MariaDB
-- Versi PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cafe`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `barang`
--

CREATE TABLE `barang` (
  `id_barang` int(11) NOT NULL,
  `nama` varchar(20) NOT NULL,
  `jenis` varchar(30) NOT NULL,
  `harga` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `barang`
--

INSERT INTO `barang` (`id_barang`, `nama`, `jenis`, `harga`) VALUES
(1, 'Espresso', 'Beverage', 30000),
(2, 'Cappuccino', 'Beverage', 35000),
(3, 'Latte', 'Beverage', 35000),
(4, 'Americano', 'Beverage', 32000),
(5, 'Mocha', 'Beverage', 37000),
(6, 'Flat White', 'Beverage', 34000),
(7, 'Macchiato', 'Beverage', 33000),
(8, 'Hot Chocolate', 'Beverage', 30000),
(9, 'Green Tea Latte', 'Beverage', 38000),
(10, 'Iced Coffee', 'Beverage', 35000),
(11, 'Iced Latte', 'Beverage', 36000),
(12, 'Iced Mocha', 'Beverage', 38000),
(13, 'Iced Americano', 'Beverage', 33000),
(14, 'Iced Green Tea', 'Beverage', 37000),
(15, 'Iced Chocolate', 'Beverage', 35000),
(16, 'Croissant', 'Pastry', 25000),
(17, 'Blueberry Muffin', 'Pastry', 22000),
(18, 'Chocolate Muffin', 'Pastry', 22000),
(19, 'Cinnamon Roll', 'Pastry', 27000),
(20, 'Bagel with Cream Che', 'Pastry', 28000),
(21, 'Fruit Tart', 'Dessert', 30000),
(22, 'Cheesecake', 'Dessert', 35000),
(23, 'Brownie', 'Dessert', 30000),
(24, 'Chocolate Cake', 'Dessert', 38000),
(25, 'Carrot Cake', 'Dessert', 37000),
(26, 'Sandwich', 'Food', 45000),
(27, 'Chicken Wrap', 'Food', 40000),
(28, 'Caesar Salad', 'Food', 38000),
(29, 'Greek Salad', 'Food', 36000),
(30, 'Pasta', 'Food', 50000);

-- --------------------------------------------------------

--
-- Struktur dari tabel `detail_transaksi`
--

CREATE TABLE `detail_transaksi` (
  `id_pelanggan` int(11) NOT NULL,
  `nama_barang` varchar(20) NOT NULL,
  `jenis` varchar(30) NOT NULL,
  `quantity` int(11) NOT NULL,
  `harga` int(11) NOT NULL,
  `hargaQTY` double NOT NULL,
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `detail_transaksi`
--

INSERT INTO `detail_transaksi` (`id_pelanggan`, `nama_barang`, `jenis`, `quantity`, `harga`, `hargaQTY`, `id`) VALUES
(95, 'Flat White', 'Beverage', 3, 34000, 68000, 22),
(96, 'Bagel with Cream Che', 'Pastry', 1, 28000, 112000, 22),
(97, 'Americano', 'Beverage', 1, 32000, 32000, 22),
(100, '', '', 3, 34000, 102000, 22);

-- --------------------------------------------------------

--
-- Struktur dari tabel `pegawai`
--

CREATE TABLE `pegawai` (
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `pegawai`
--

INSERT INTO `pegawai` (`username`, `password`) VALUES
('nopeng', '123220202');

-- --------------------------------------------------------

--
-- Struktur dari tabel `riwayat_transaksi`
--

CREATE TABLE `riwayat_transaksi` (
  `id` int(11) NOT NULL,
  `Total_biaya` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `total`
--

CREATE TABLE `total` (
  `id` int(11) NOT NULL,
  `Total_biaya` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `total`
--

INSERT INTO `total` (`id`, `Total_biaya`) VALUES
(22, 68000),
(22, 180000),
(22, 212000),
(22, 212000),
(22, 212000),
(22, 314000);

-- --------------------------------------------------------

--
-- Struktur dari tabel `transaksi`
--

CREATE TABLE `transaksi` (
  `id` int(11) NOT NULL,
  `nama_pelanggan` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `transaksi`
--

INSERT INTO `transaksi` (`id`, `nama_pelanggan`) VALUES
(22, 'Udin'),
(24, 'novan');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `barang`
--
ALTER TABLE `barang`
  ADD PRIMARY KEY (`id_barang`);

--
-- Indeks untuk tabel `detail_transaksi`
--
ALTER TABLE `detail_transaksi`
  ADD PRIMARY KEY (`id_pelanggan`);

--
-- Indeks untuk tabel `transaksi`
--
ALTER TABLE `transaksi`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `barang`
--
ALTER TABLE `barang`
  MODIFY `id_barang` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT untuk tabel `detail_transaksi`
--
ALTER TABLE `detail_transaksi`
  MODIFY `id_pelanggan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=101;

--
-- AUTO_INCREMENT untuk tabel `transaksi`
--
ALTER TABLE `transaksi`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
